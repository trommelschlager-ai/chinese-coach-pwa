# Panda Go — lesson 3: Xiaoxiao v263

Recorded 101 complete number phrases, 0–100.

Source batches:

- luvvoice.com-20261111-dQrmDQ.mp3: 0–20
- luvvoice.com-20261111-1DWBvq.mp3: 21–40
- luvvoice.com-20261111-cthCnW.mp3: 41–60
- luvvoice.com-20261111-BPkwYj.mp3: 61–80
- luvvoice.com-20261111-bFUV4t.mp3: 81–100

- Silence segmentation counts verified: 21+20+20+20+20.
- No missing audio filenames.
- Replaces old Yue Tan fragments and word-by-word splices.
- 一百 must be yì bǎi, **not** isolated yī + bǎi. Manual tone review still required.
- Commercial Luvvoice rights need verification before selling.
- No live deployment was performed by this local process.
